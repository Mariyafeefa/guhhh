package com.example.saradalik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaradalikApplicationTests {

	@Test
	void contextLoads() {
	}

}
